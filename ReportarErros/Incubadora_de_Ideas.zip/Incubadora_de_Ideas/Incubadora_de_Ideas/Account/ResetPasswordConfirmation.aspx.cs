﻿using System.Web.UI;

namespace Incubadora_de_Ideas.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}