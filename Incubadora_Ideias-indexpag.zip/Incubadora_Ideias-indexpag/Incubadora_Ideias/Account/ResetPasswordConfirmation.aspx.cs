﻿using System.Web.UI;

namespace Incubadora_Ideias.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}